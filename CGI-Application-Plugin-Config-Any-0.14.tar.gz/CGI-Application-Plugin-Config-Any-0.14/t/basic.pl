{
   name      => 'TestApp',
    Component => { 'Controller::Foo' => { foo => 'bar' } },
    Model     => { 'Model::Baz' => { qux => 'xyzzy' } },
    deep      => { 'buried' => { 'key' => 'value' } },
}
